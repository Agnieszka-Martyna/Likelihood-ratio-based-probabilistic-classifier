source("../../EW_within_functions/duplex.R")
source("../../EW_within_functions/KS.R")
source("../../EW_within_functions/robUC_function.R")
source("../../EW_within_functions/LR_KDE_comparison_function_three_level_EhWhB.R")
source("../../EW_within_functions/p_EhWhB.R")
source("../../EW_within_functions/ECE_function.R")
source("../../EW_within_functions/PLSDA_wines_function.R")

library(mvtnorm)

population = read.table("wines_data13.txt", header = TRUE)
data.analysed = population
variables.list = list(colnames(population[,-c(1:3)]))
variables = which(colnames(population) %in% variables.list[[1]])
population.Factor.Item = aggregate(population[,1:2],by=list(population$Item),FUN=unique)[,-1]
population.means = aggregate(population[,variables],by=list(population$Item),FUN=mean)[,-1]
population.means = cbind(population.Factor.Item,Piece=rep(1,times=nrow(population.means)),population.means)

cats = unique(population.means$Factor)
cat.list = rep(list(1),length(cats))
for (f in 1:length(cats))
{
  cat.list[[f]] = unique(population.means[which(population.means$Factor==cats[f]),"Item"])
}

Sets=2
MODEL=TEST1=TEST2=NULL
for (s in 1:length(cats))
{
  duplex_res = duplex(as.matrix(population.means[cat.list[[s]],-c(1:3)]),Sets=Sets) #KS(population.means[cat.list[[s]],-c(1:3)],k=0.6*nrow(population.means[cat.list[[s]],-c(1:3)])) #
  MODEL = c(MODEL,duplex_res$model+cat.list[[s]][1]-1)
  TEST1 = c(TEST1,duplex_res$test1+cat.list[[s]][1]-1)
}

population_model = population[which(population$Item %in% MODEL),]
population_model$Item = rep(1:length(unique(population_model$Item)),each=length(unique(population_model$Piece)))
population_test1 = population[which(population$Item %in% TEST1),]
population_test1$Item = rep(1:length(unique(population_test1$Item)),each=length(unique(population_test1$Piece)))

population.list = list(population_model,population_test1)

for (sets in 1:Sets)
{
  if (sets==1)   population = population.list[[1]]
  if (sets==2)   population = population.list[[2]]
  
  data.analysed = population
  
  items = unique(population$Item)
  m.all.analysed = length(unique(data.analysed$Item))
  variables.list = variables.list#,c("logFeO"))#,c("logFeO"))#list(c("logNaO","logSiO","logCaO"))
  ND = c("N")
  n = length(unique(data.analysed$Piece)) 
  
  output.matrix.KDE = output.matrix.PLSDA = output.matrix.d.mean=output.matrix.obs.diff=matrix(1,ncol = m.all.analysed, nrow = m.all.analysed,dimnames=list(c(as.character(unique(data.analysed$Name))),c( as.character(unique(data.analysed$Name)))))
  
  for (v in 1:length(variables.list))
  {
    variables = variables.list[[v]]
    variable.name="wines"
    variables = which(colnames(population) %in% variables)
    p = length(variables) 
    
    for (i in 1:m.all.analysed)
    {  
      for (j in 1:m.all.analysed) 
      {	
        if (i == j) 
        {
          y.1.2 = data.analysed[which(data.analysed$Item == items[i]),] 
          y.1 = data.frame(y.1.2[1,]) 
          y.2 = data.frame(y.1.2[1,]) 
          
          population = data.analysed[which(data.analysed$Item != items[i]),] 
          m = length(unique(population$Item)) 
        }
        else 
        {
          y.1 = data.frame(data.analysed[which(data.analysed$Item == items[i]),])
          y.2 = data.frame(data.analysed[which(data.analysed$Item == items[j]),]) 
          
          population = data.analysed[which(!data.analysed$Item %in% c(items[i],items[j])),]
          m = length(unique(population$Item)) 
        }
 
        results.UC = UC(population=population, variables) 
        E = results.UC$E
        W = results.UC$W
        B = results.UC$B
	      train_set = results.UC$train
         
        n.1 = length(y.1$Item) 
        n.2 = length(y.2$Item) 
        
        y.mean.1 = matrix(apply(as.matrix(y.1[,variables]), 2, mean), nrow = 1) 
        y.mean.2 = matrix(apply(as.matrix(y.2[,variables]), 2, mean), nrow = 1) 
        y.star = (n.1*y.mean.1+n.2*y.mean.2)/(n.1+n.2)    
        
        nclass = length(unique(data.analysed$Factor))
        hb = (4/nclass/(p+2))^(1/(p+4))
        hw = (4/length(unique(train_set$Item))/(p+2))^(1/(p+4))
        
        results.LR.KDE= LR.KDE.function(y.mean.1, y.mean.2, y.star, E, W, B, hb,hw, train_set, variables, p, n.1, n.2)
        LR.KDE = results.LR.KDE$LR.KDE
        
        results.PLSDA = PLSDA_function(train_set=train_set,y.mean.1=y.mean.1,variables_PLSDA=variables,y.1.2=y.1.2,complexity=2)$predicted_test_01
        
        if (ND[v] == "N")
        {
          output.matrix.KDE[i,j] = output.matrix.KDE[i,j] * LR.KDE
          output.matrix.PLSDA[i,j] = output.matrix.PLSDA[i,j] * results.PLSDA
        } else
        {
          output.matrix.KDE[i,j] = output.matrix.KDE[i,j] * 1/LR.KDE
          output.matrix.PLSDA[i,j] = output.matrix.PLSDA[i,j] * results.PLSDA
        }
        
        results.p.KDE= p.function(y.mean.1, y.mean.2,  E, W, B, hb,hw, train_set, variables, p, n.1, n.2)
        output.matrix.d.mean[i,j] = results.p.KDE$d.mean
        output.matrix.obs.diff[i,j] = results.p.KDE$obs.diff
      }	
    }	
  }
  if (sets==1) {
    output.matrix.KDE_model = output.matrix.KDE
    output.matrix.d.mean_model=output.matrix.d.mean
    output.matrix.obs.diff_model=output.matrix.obs.diff
    output.matrix.PLSDA_model=output.matrix.PLSDA
    }
  if (sets==2) {
    output.matrix.KDE_test1 = output.matrix.KDE
    output.matrix.d.mean_test1=output.matrix.d.mean
    output.matrix.obs.diff_test1=output.matrix.obs.diff
    output.matrix.PLSDA_test1=output.matrix.PLSDA
    }
}

write.table(output.matrix.KDE_model,"output.matrix.KDE_model.txt",sep="\t")
write.table(output.matrix.d.mean_model,"output.matrix.d.mean_model.txt",sep="\t")
write.table(output.matrix.obs.diff_model,"output.matrix.obs.diff_model.txt",sep="\t")
write.table(output.matrix.PLSDA_model,"output.matrix.PLSDA_model.txt",sep="\t")

write.table(output.matrix.KDE_test1,"output.matrix.KDE_test1.txt",sep="\t")
write.table(output.matrix.d.mean_test1,"output.matrix.d.mean_test1.txt",sep="\t")
write.table(output.matrix.obs.diff_test1,"output.matrix.obs.diff_test1.txt",sep="\t")
write.table(output.matrix.PLSDA_test1,"output.matrix.PLSDA_test1.txt",sep="\t")

par(mfrow=c(2,2))
# output.matrix.KDE_model[which(log10(output.matrix.KDE_model)==-Inf,arr.ind=T)] = min(output.matrix.KDE_model[which(!log10(output.matrix.KDE_model)==-Inf,arr.ind=T)])
# output.matrix.KDE_test1[which(log10(output.matrix.KDE_test1)==-Inf,arr.ind=T)] = min(output.matrix.KDE_test1[which(!log10(output.matrix.KDE_test1)==-Inf,arr.ind=T)])
# output.matrix.KDE_model[which(is.na(log10(output.matrix.KDE_model)),arr.ind=T)]  = 1
# output.matrix.KDE_test1[which(is.na(log10(output.matrix.KDE_test1)),arr.ind=T)] = 1
    diag(output.matrix.KDE_model) = NA
    diag(output.matrix.KDE_test1) = NA

    plot3D:::scatter3D(output.matrix.d.mean_model,output.matrix.obs.diff_model, log10(output.matrix.KDE_model), phi = 10,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
    plot3D:::scatter3D(output.matrix.d.mean_model,output.matrix.obs.diff_model, log10(output.matrix.KDE_model), phi = 90,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
    plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, log10(output.matrix.KDE_test1), phi =10,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
    plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, log10(output.matrix.KDE_test1), phi =90,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
dev.copy(png,paste(variable.name,"_3D",".png",sep=""),height=1000,width=1000);dev.off()
dev.copy(postscript,paste(variable.name,"_3D",".eps",sep=""),height=1000,width=1000);dev.off()
par(mfrow=c(1,1))

##check stability of the LR from PLSDA for each sample
boxplot(t((output.matrix.PLSDA_model)))
boxplot(t((output.matrix.PLSDA_test1)))

cats_model = unique(population_model$Factor)
cat.list_model = rep(list(1),length(cats_model))
for (f in 1:length(cats_model))
{
  cat.list_model[[f]] = unique(population_model[which(population_model$Factor==cats_model[f]),"Item"])
}

cats_test1 = unique(population_test1$Factor)
cat.list_test1 = rep(list(1),length(cats_test1))
for (f in 1:length(cats_test1))
{
  cat.list_test1[[f]] = unique(population_test1[which(population_test1$Factor==cats_test1[f]),"Item"])
}

source("../../EW_within_functions/logit_maxapproach_function.R")
logit_res_KDE = logit(LR.matrix_test1=(output.matrix.KDE_model),LR.matrix_test2=(output.matrix.KDE_test1),cat.list_test1=cat.list_model)$p
dev.copy(png,paste(variable.name,"_logit_curve",".png",sep=""),height=1000,width=1000);dev.off()
dev.copy(postscript,paste(variable.name,"_logit_curve",".eps",sep=""),height=1000,width=1000);dev.off()


true = aggregate(population_test1$Factor,by=list(population_test1$Item),unique)[,-1]

source("../../EW_within_functions/classification_outcome_withoutWeights_function.r")
classification.outcomes.KDE = classification.outcomes(LR.matrix = output.matrix.KDE_test1,p.matrix=logit_res_KDE,cats=cats_test1,cat.list=cat.list_test1,variant="KDE")
matrix01 = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=length(cats))
classification.outcomes.KDE$accuracy.fuzzy
write.table(classification.outcomes.KDE$fuzzy.classification,"detailed_class.txt",sep="\t",quote=F)
write.table(classification.outcomes.KDE$accuracy.fuzzy,"acc_class.txt",sep="\t",quote=F)

par(mfrow=c(3,1),mar=c(5,4.5,2,2))
g=barplot(t(classification.outcomes.KDE$fuzzy.classification[cat.list_test1[[1]],c(4:6)])/100,col=c(7,5,6),ylab="class probability",xlab="class 1",beside=T,names=cat.list_test1[[1]],cex.axis=2,cex.lab=2)
# abline(h=1/3,col="red",lwd=2)
g=barplot(t(classification.outcomes.KDE$fuzzy.classification[cat.list_test1[[2]],c(5,4,6)])/100,col=c(5,7,6),ylab="class probability",xlab="class 2",beside=T,names=cat.list_test1[[2]],cex.axis=2,cex.lab=2)
# abline(h=1/3,col="red",lwd=2)
g=barplot(t(classification.outcomes.KDE$fuzzy.classification[cat.list_test1[[3]],c(6,5,4)])/100,col=c(6,5,7),ylab="class probability",xlab="class 3",beside=T,names=cat.list_test1[[3]],cex.axis=2,cex.lab=2)
# abline(h=1/3,col="red",lwd=2)
dev.copy(png,paste(variable.name,"_LR_classification_barplot2",".png",sep=""));dev.off()
dev.copy(postscript,paste(variable.name,"_LR_classification_barplot2",".eps",sep=""));dev.off()

par(mfrow=c(1,3))
boxplot(classification.outcomes.KDE$fuzzy.classification[,1]~true,col=c(2,1,1),ylab="membership probabilities");abline(h=0.5,col="red",lwd=2)
boxplot(classification.outcomes.KDE$fuzzy.classification[,2]~true,col=c(1,2,1),ylab="membership probabilities");abline(h=0.5,col="red",lwd=2)
boxplot(classification.outcomes.KDE$fuzzy.classification[,3]~true,col=c(1,1,2),ylab="membership probabilities");abline(h=0.5,col="red",lwd=2)
par(mfrow=c(1,1))
dev.copy(png,paste(variable.name,"LR_classification_boxplot",".png",sep=""));dev.off()
dev.copy(postscript,paste(variable.name,"LR_classification_boxplot",".eps",sep=""));dev.off()

plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, (logit_res_KDE), phi = 10, pch=16,bty ="g",type="v",xlab="mean d",ylab="diff d",zlab="probability",ticktype="detailed")
dev.copy(png,paste(variable.name,"LR_3D_logit",".png",sep=""));dev.off()
dev.copy(postscript,paste(variable.name,"LR_3D_logit",".eps",sep=""));dev.off()


true_model = aggregate(population_model$Factor,by=list(population_model$Item),unique)[,-1]
true_test1 = aggregate(population_test1$Factor,by=list(population_test1$Item),unique)[,-1]

p_PLSDA_test1 = apply(output.matrix.PLSDA_test1,1,mean,na.rm=T)
predicted_class = round(p_PLSDA_test1,0);predicted_class[which(predicted_class< -1)]=-1;predicted_class[which(predicted_class>1)]=1
table(true_test1-2,predicted_class)/rowSums(table(true_test1-2,predicted_class))
g=barplot(p_PLSDA_test1,col=rep(c(3,4),each=length(cat.list_test1[[1]])),ylab="predicted response",cex.lab=2)
abline(h=0.5,lwd=2,col="red")
axis(1,at=g[c(20,60)],c("p","cw"),cex.axis=2)
dev.copy(png,paste(variable.name,"PLSDA_classification_barplot2",".png",sep=""));dev.off()
dev.copy(postscript,paste(variable.name,"PLSDA_classification_barplot2",".eps",sep=""));dev.off()

# par(mfrow=c(2,2))
# dd = output.matrix.KDE_test1
# q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
# a =b=d= NULL
# for (e in 1:nrow(q))
# {
#   a = c(a,dd[q[e,1]:q[e,2],q[e,1]:q[e,2]])
#   b=c(b,output.matrix.d.mean_test1[q[e,1]:q[e,2],q[e,1]:q[e,2]])
#   d=c(d,output.matrix.obs.diff_test1[q[e,1]:q[e,2],q[e,1]:q[e,2]])
# }
# 
# tmpa = dd
# tmpb=output.matrix.d.mean_test1
# tmpc =output.matrix.obs.diff_test1
# for (e in 1:nrow(q))
# {
#   tmpa[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
#   tmpb[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
#   tmpc[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NAsd
# }
# 
# tmpa = tmpa[which(!is.na(tmpa))]fsdfdfsdfsfdfsfdfsdfsdfsdfdsfdsfdsfdf
# tmpb = tmpb[which(!is.na(tmpb))]
# tmpc = tmpc[which(!is.na(tmpc))]
# 
# plot3D:::scatter3D(tmpb,tmpc, log10(tmpa), phi = 0, bty ="g",type="v",xlab="d1",ylab="d2",zlab="different class log10LR", ticktype = "detailed")
# plot3D:::scatter3D(b,d, log10(a), phi = 0, bty ="g",type="v",xlab="d1",ylab="d2",zlab="same class log10LR", ticktype = "detailed")
# par(mfrow=c(1,2))
# plot3D:::scatter3D(tmpb,tmpc, log10(tmpa), phi = 20, bty ="g",type="v",xlab="d1",ylab="d2",zlab="different class log10LR", ticktype = "detailed")
# plot3D:::scatter3D(b,d, log10(a), phi = 20, bty ="g",type="v",xlab="d1",ylab="d2",zlab="same class log10LR", ticktype = "detailed")
# dev.copy(png,paste(variable.name,"LR_same_diff_LR",".png",sep=""));dev.off()
# dev.copy(postscript,paste(variable.name,"LR_same_diff_LR",".eps",sep=""));dev.off()
# par(mfrow=c(1,2))
# hist(log10(tmpa))
# hist(log10(a))
# dev.copy(png,paste(variable.name,"LR_same_diff_LR_hist",".png",sep=""));dev.off()
# dev.copy(postscript,paste(variable.name,"LR_same_diff_LR_hist",".eps",sep=""));dev.off()

# dd2 = output.matrix.KDE_test1
# q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
# a =NULL
# for (e in 1:nrow(q))
# {
#   dd2[q[e,1]:q[e,2],q[e,1]:q[e,2]] = ifelse(output.matrix.KDE_test1[q[e,1]:q[e,2],q[e,1]:q[e,2]]>1,-1,-3)
# }
# 
# dd2[dd2>1]= 1 
# dd2[dd2>0 & dd2<1]= 2
# 
# min(dd2)
# max(dd2)
# 
# col = dd2
# col[col==-1] = "green";col[col==-3] = "red";col[col==1] = "violet";col[col==2] = "darkgreen"
# plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, (dd2), phi = 20, bty ="g",type="h",ticktype="detailed",pch = 16,cex=0.5)
# plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, (dd2), phi = 90, bty ="g",type="h",ticktype="detailed",pch = 16,cex=0.5)
# 
# plot(output.matrix.d.mean_test1,output.matrix.obs.diff_test1,col=col,pch=16,cex=0.5)
# legend("bottomleft",c("FP","TP","FN","TN"),col=c("violet","green","red","darkgreen"),pch=16)
# dev.copy(png,paste(variable.name,"LR_FPFNTPTN",".png",sep=""));dev.off()
# dev.copy(postscript,paste(variable.name,"LR_FPFNTPTN",".eps",sep=""));dev.off()





# mask_H1 = matrix(NA,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1))
# q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
# for (e in 1:nrow(q))
# {
#   mask_H1[q[e,1]:q[e,2],q[e,1]:q[e,2]] = 1
# }
# mask_H2 = matrix(1,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1))
# q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
# for (e in 1:nrow(q))
# {
#   mask_H2[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
# }
# 
# 
# 
# which_FP = which(mask_H2==1 & output.matrix.KDE_test1>1)
# which_TN = which(mask_H2==1 &  output.matrix.KDE_test1<1)
# which_FN = which(mask_H1== 1 & output.matrix.KDE_test1<1)
# which_TP = which(mask_H1== 1 & output.matrix.KDE_test1>1)
# 
# mask_FP = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_FP[which_FP] = 1
# mask_TN = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_TN[which_TN] = 1
# mask_FN = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_FN[which_FN] = 1
# mask_TP = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_TP[which_TP] = 1
# 
# mask = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask[which_FP] = 1;mask[which_TN] = 2;mask[which_FN] = 3;mask[which_TP] = 4
# plot(output.matrix.d.mean_test1,output.matrix.obs.diff_test1,col=mask,cex=0.8,pch=16,,xlab="p1",ylab="p2")
# legend("topright",c("FP","TN","FN","TP"),col=c(1:4),pch=16,cex=0.7)
# dev.copy(png,paste(variable.name,"LR_FPFNTPTN",".png",sep=""));dev.off()
# dev.copy(postscript,paste(variable.name,"LR_FPFNTPTN",".eps",sep=""));dev.off()
# 
# 

par(mfrow=c(1,1),mar=c(5,15,4,2))
image(1:nrow(output.matrix.KDE_test1),1:ncol(output.matrix.KDE_test1),log10(output.matrix.KDE_test1),xlab="control samples",ylab="recovered samples",cex.lab=2,cex.axis=2)
dev.copy(postscript, paste(variable.name,"_LR_image",".eps", sep=""));dev.off()
dev.copy(png,paste(variable.name,"_LR_image",".png",sep=""));dev.off()

image(1:nrow(output.matrix.KDE_model),1:ncol(output.matrix.KDE_model),log10(output.matrix.KDE_model),xlab="control samples",ylab="recovered samples",cex.lab=2,cex.axis=2)
image(1:nrow(logit_res_KDE),1:ncol(logit_res_KDE),logit_res_KDE,xlab="control samples",ylab="recovered samples",cex.lab=2,cex.axis=2)
dev.copy(postscript, paste(variable.name,"_p_image",".eps", sep=""));dev.off()
dev.copy(png,paste(variable.name,"_p_image",".png",sep=""));dev.off()


par(mfrow=c(2,2))
for (u in 1:13)
{
  plot(density(population_model[cat.list_model[[1]],u+3],bw=var(population_model[cat.list_model[[1]],u+3])),col=as.character(population_model$Factor[cat.list_model[[1]]]),xlim=c(min(population_model[,u+3]),max(population_model[,u+3])), main=colnames(population_model)[u+3])
  lines(density(population_model[cat.list_model[[2]],u+3],bw=var(population_model[cat.list_model[[2]],u+3])),col=as.character(population_model$Factor[cat.list_model[[2]]]))
  lines(density(population_model[cat.list_model[[3]],u+3],bw=var(population_model[cat.list_model[[3]],u+3])),col=as.character(population_model$Factor[cat.list_model[[3]]]))
}

par(mfrow=c(2,2))
for (u in 1:13)
{
  plot(density(population_test1[cat.list_test1[[1]],u+3],bw=var(population_test1[cat.list_model[[1]],u+3])),col=as.character(population_test1$Factor[cat.list_test1[[1]]]),xlim=c(min(population_test1[,u+3]),max(population_test1[,u+3])), main=colnames(population_test1)[u+3])
  lines(density(population_test1[cat.list_test1[[2]],u+3],bw=var(population_test1[cat.list_model[[2]],u+3])),col=as.character(population_test1$Factor[cat.list_test1[[2]]]))
  lines(density(population_test1[cat.list_test1[[3]],u+3],bw=var(population_test1[cat.list_model[[3]],u+3])),col=as.character(population_test1$Factor[cat.list_test1[[3]]]))
}

par(mfrow=c(2,2))
for (u in 1:13)
{
  plot(rep(1,90),(population_model[,u+3]),col=as.character(population_model$Factor), main=colnames(population_model)[u+3],cex=0.6,pch=16)
}

par(mfrow=c(2,2))
for (u in 1:13)
{
  plot((population_test1[cat.list_test1[[1]],u+3]),col=as.character(population_test1$Factor[cat.list_test1[[1]]]),xlim=c(min(population_test1[,u+3]),max(population_test1[,u+3])), main=colnames(population_test1)[u+3])
  points((population_test1[cat.list_test1[[2]],u+3]),col=as.character(population_test1$Factor[cat.list_test1[[2]]]))
  points((population_test1[cat.list_test1[[3]],u+3]),col=as.character(population_test1$Factor[cat.list_test1[[3]]]))
}

