#compelxity
predicted_test = cbind(population_test1[,1:3],matrix(NA,nrow=nrow(population_test1),ncol=1))
predicted_test_1 = aggregate(predicted_test[,1:2],by=list(predicted_test$Item),unique)[,-1]
predicted_test_2 = aggregate(population_test1[,-c(1:3)],by=list(predicted_test$Item),mean)[,-1]
predicted_test = cbind(predicted_test_1,Piece=1,predicted_test_2)
class = ifelse(population_test1$Factor==cats[1],0,1)
class = aggregate(class,by=list(population_test1$Item),unique)[,-1]

train_plsda = cbind(class=class,predicted_test[,variables])

correct=NULL
predicted=matrix(NA, nrow=nrow(predicted_test),ncol=1)
for (nc in 1:5)
{
  for (t in 1:nrow(predicted_test))
  {
    ind = which(predicted_test$Item==t)
    obj = train_plsda[ind,]

    train_plsda_cv = train_plsda[-ind,]
    means = matrix(apply(train_plsda_cv,2,mean),nrow=length(ind),ncol=ncol(train_plsda_cv), byrow=T)
    train_plsda.sc = apply(train_plsda_cv,2,scale,scale=F,center=T)
    plsda_results = plsr(class~.,data=as.data.frame(train_plsda.sc), scale = F, center=F,validation = "none")

    test_plsda.sc = obj[,-1] - means[,-1]
    predicted[ind,1] = predict(plsda_results,newdata=(test_plsda.sc),ncomp=nc) + means[,1]

  }

  # predicted_test_aggr = aggregate(predicted_test[,-c(1:3)],by=list(predicted_test$Item),FUN=mean)[,-1]

  # predicted_class = ifelse(predicted_test_aggr>0.5,cats[2],cats[1])
  predicted_class = ifelse(predicted>0.5,1,0)
  correct = c(correct,length(which(predicted_class == class))/length(class))

}
plot(correct,type="p",pch=16)