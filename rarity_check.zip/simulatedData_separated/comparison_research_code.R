source("../../EW_within_functions/duplex.R")
source("../../EW_within_functions/KS.R")
source("../../EW_within_functions/robUC_function.R")
source("../../EW_within_functions/LR_KDE_comparison_function_three_level_EhWhB.R")
source("../../EW_within_functions/p_EhWhB.R")
source("../../EW_within_functions/ECE_function.R")

library(mvtnorm)
variances = seq(0.1,1,0.2)
for (r1 in 1:length(variances))
{
  for (r2  in 1:5)
  {
    dir.create(paste(r1,r2))
    dirName = paste(r1,r2)
    setwd((dirName))
    # positions = c(sample(c(1,5,6)) + rnorm(3,0,0.1),sample(c(7,8,10)) + rnorm(3,0,0.1),sample(c(11,12,15)) + rnorm(3,0,0.1))
    # positions = c(sample(c(1,5,6)) + rnorm(3,0,0.1),sample(c(7,8,10)) + rnorm(3,0,0.1),sample(c(11,12,15)) + rnorm(3,0,0.1))
    # positions = c(sort(positions[1:3]),sort(positions[4:6]),sort(positions[7:9]))
    positions = c(sample(c(1,5,6,7,8,10,11,12,15)) + rnorm(9,0,0.1))
    
    var1c1M = rnorm(40,positions[4],variances[r1])
    var1c1S = rnorm(5,positions[1],variances[r1])
    var1c1L = rnorm(5,positions[7],variances[r1])
    var1c1 = c(var1c1S,var1c1M,var1c1L)
    # plot(density(var1c1))
    
    
    var1c2M = rnorm(40,positions[5],variances[r1])
    var1c2S = rnorm(5,positions[2],variances[r1])
    var1c2L = rnorm(5,positions[8],variances[r1])
    var1c2 = c(var1c2S,var1c2M,var1c2L)
    # plot(density(var1c2))
    
    var1c3M = rnorm(40,positions[6],variances[r1])
    var1c3S = rnorm(5,positions[3],variances[r1])
    var1c3L = rnorm(5,positions[9],variances[r1])
    var1c3 = c(var1c3S,var1c3M,var1c3L)
    # plot(density(var1c3))
    
    var1 = c(var1c1,var1c2,var1c3)
    
    var2c1M = rnorm(40,1.45,0.06)
    var2c1S = rnorm(5,0.45,0.06)
    var2c1L = rnorm(5,2.0,0.06)
    var2c1 = c(var2c1S,var2c1M,var2c1L)
    # plot(density(var1c1))
    
    
    var2c2M = rnorm(40,0.9,0.1)
    var2c2S = rnorm(5,0.4,0.1)
    var2c2L = rnorm(5,1.55,0.1)
    var2c2 = c(var2c2S,var2c2M,var2c2L)
    # plot(density(var1c2))
    
    var2c3M = rnorm(40,1.2,0.1)
    var2c3S = rnorm(5,0.55,0.1)
    var2c3L = rnorm(5,2.2,0.1)
    var2c3 = c(var2c3S,var2c3M,var2c3L)
    # plot(density(var1c3))
    
    var2 = c(rnorm(50,3,0.05),rnorm(50,3,0.05),rnorm(50,3,0.05))#c(var2c1,var2c2,var2c3)#
    
    vars = cbind(var1,var2)
    new=NULL
    for (i in 1:nrow(vars))
    {
      new = rbind(new, vars[i,] + c(rnorm(1,0,0.01),rnorm(1,0,0.01)))
      new = rbind(new, vars[i,] + c(rnorm(1,0,0.01),rnorm(1,0,0.01)))
      new = rbind(new, vars[i,] + c(rnorm(1,0,0.01),rnorm(1,0,0.01)))
    }
    
    Factor = rep(c("class1","class2","class3"),each=150)
    Item = rep(1:150,each=3)
    Piece = rep(1:3,times=150)
    
    simData = data.frame(Factor=Factor,Item=Item,Piece=Piece,V1=new[,1],V2=new[,2])
    write.table(simData,"simulatedData.txt",quote=F,row.names = F,sep="\t")
    population = read.table("simulatedData.txt", header = TRUE)

    data.analysed = population
    variables.list = list(c("V1"))#list(colnames(population)[-c(1:3)])
    variables = which(colnames(population) %in% variables.list[[1]])
    population.Factor.Item = aggregate(population[,1:2],by=list(population$Item),FUN=unique)[,-1]
    population.means = as.matrix(aggregate(as.matrix(population[,variables]),by=list(population$Item),FUN=mean)[,-1])
    population.means = cbind(population.Factor.Item,Piece=rep(1,times=nrow(population.means)),population.means)
    
    cats = unique(population.means$Factor)
    cat.list = rep(list(1),length(cats))
    for (f in 1:length(cats))
    {
      cat.list[[f]] = unique(population.means[which(population.means$Factor==cats[f]),"Item"])
    }
    
    Sets=2
    MODEL=TEST1=TEST2=NULL
    for (s in 1:length(cats))
    {
      duplex_res = duplex(as.matrix(population.means[cat.list[[s]],-c(1:3)]),Sets=Sets) #KS(as.matrix(population.means[cat.list[[s]],-c(1:3)]),k=0.6*nrow(as.matrix(population.means[cat.list[[s]],-c(1:3)]))) #
      MODEL = c(MODEL,duplex_res$model+cat.list[[s]][1]-1)
	  TEST1 = c(TEST1,duplex_res$test1+cat.list[[s]][1]-1)
    }
    
    population_model = population[which(population$Item %in% MODEL),]
    population_model$Item = rep(1:length(unique(population_model$Item)),each=length(unique(population_model$Piece)))
    population_test1 = population[which(population$Item %in% TEST1),]
    population_test1$Item = rep(1:length(unique(population_test1$Item)),each=length(unique(population_test1$Piece)))

    population.list = list(population_model,population_test1)

      for (sets in 1:Sets)
      {
        if (sets==1)   population = population.list[[1]]
        if (sets==2)   population = population.list[[2]]
        
        data.analysed = population
        
        items = unique(population$Item)
        m.all.analysed = length(unique(data.analysed$Item))
        variables.list = variables.list#,c("logFeO"))#,c("logFeO"))#list(c("logNaO","logSiO","logCaO"))
        ND = c("N")
        n = length(unique(data.analysed$Piece)) 
                
  output.matrix.KDE = output.matrix.PLSDA = output.matrix.d.mean=output.matrix.obs.diff=matrix(1,ncol = m.all.analysed, nrow = m.all.analysed,dimnames=list(c(as.character(unique(data.analysed$Name))),c( as.character(unique(data.analysed$Name)))))
 
        for (v in 1:length(variables.list))
        {
          variables = variables.list[[v]]
          variable.name="sim"
          variables = which(colnames(population) %in% variables)
          p = length(variables) 
     
          for (i in 1:m.all.analysed)
          {  
            for (j in 1:m.all.analysed) 
            {	
              if (i == j) 
              {
                y.1.2 = data.analysed[which(data.analysed$Item == items[i]),] 
                y.1 = data.frame(y.1.2[1,]) 
                y.2 = data.frame(y.1.2[2:3,]) 
                
                population = data.analysed[which(data.analysed$Item != items[i]),] 
                m = length(unique(population$Item)) 
              }
              else 
              {
                y.1 = data.frame(data.analysed[which(data.analysed$Item == items[i]),])
                y.2 = data.frame(data.analysed[which(data.analysed$Item == items[j]),]) 
                
                population = data.analysed[which(!data.analysed$Item %in% c(items[i],items[j])),]
                m = length(unique(population$Item)) 
              }

              results.UC = UC(population=population, variables)
              E = results.UC$E
              W = results.UC$W
              B = results.UC$B
              train_set = results.UC$train            
              
              n.1 = length(y.1$Item) 
              n.2 = length(y.2$Item) 
              
              y.mean.1 = matrix(apply(as.matrix(y.1[,variables]), 2, mean), nrow = 1) 
              y.mean.2 = matrix(apply(as.matrix(y.2[,variables]), 2, mean), nrow = 1) 
              y.star = (n.1*y.mean.1+n.2*y.mean.2)/(n.1+n.2)    
              
              nclass = length(unique(data.analysed$Factor))
              hb = (4/nclass/(p+2))^(1/(p+4))
              hw = (4/length(unique(train_set$Item))/(p+2))^(1/(p+4))
                         
              results.LR.KDE= LR.KDE.function(y.mean.1, y.mean.2, y.star, E, W, B, hb,hw, train_set, variables, p, n.1, n.2)
              LR.KDE = results.LR.KDE$LR.KDE
              
              if (ND[v] == "N")
              {
                output.matrix.KDE[i,j] = output.matrix.KDE[i,j] * LR.KDE
              } else
              {
                output.matrix.KDE[i,j] = output.matrix.KDE[i,j] * 1/LR.KDE
              }
                           
              results.p.KDE= p.function(y.mean.1, y.mean.2,  E, W, B, hb,hw, train_set, variables, p, n.1, n.2)
              output.matrix.d.mean[i,j] = results.p.KDE$d.mean
              output.matrix.obs.diff[i,j] = results.p.KDE$obs.diff              
            }	
          }		   
        }
        if (sets==1) {
          output.matrix.KDE_model = output.matrix.KDE
          output.matrix.d.mean_model=output.matrix.d.mean
          output.matrix.obs.diff_model=output.matrix.obs.diff
        }
        if (sets==2) {
          output.matrix.KDE_test1 = output.matrix.KDE
          output.matrix.d.mean_test1=output.matrix.d.mean
          output.matrix.obs.diff_test1=output.matrix.obs.diff
        }
      }     
    
    write.table(output.matrix.KDE_model,"output.matrix.KDE_model.txt",sep="\t")
    write.table(output.matrix.d.mean_model,"output.matrix.d.mean_model.txt",sep="\t")
    write.table(output.matrix.obs.diff_model,"output.matrix.obs.diff_model.txt",sep="\t")
    
    write.table(output.matrix.KDE_test1,"output.matrix.KDE_test1.txt",sep="\t")
    write.table(output.matrix.d.mean_test1,"output.matrix.d.mean_test1.txt",sep="\t")
    write.table(output.matrix.obs.diff_test1,"output.matrix.obs.diff_test1.txt",sep="\t")
    
    # par(mfrow=c(2,2))
    # output.matrix.KDE_model[which(log10(output.matrix.KDE_model)==-Inf,arr.ind=T)] = min(output.matrix.KDE_model[which(!log10(output.matrix.KDE_model)==-Inf,arr.ind=T)])
    # output.matrix.KDE_test1[which(log10(output.matrix.KDE_test1)==-Inf,arr.ind=T)] = min(output.matrix.KDE_test1[which(!log10(output.matrix.KDE_test1)==-Inf,arr.ind=T)])
    # output.matrix.KDE_model[which(is.na(log10(output.matrix.KDE_model)),arr.ind=T)]  = 1
    # output.matrix.KDE_test1[which(is.na(log10(output.matrix.KDE_test1)),arr.ind=T)] = 1
    diag(output.matrix.KDE_model) = NA
    diag(output.matrix.KDE_test1) = NA
    
    plot3D:::scatter3D(output.matrix.d.mean_model,output.matrix.obs.diff_model, log10(output.matrix.KDE_model), phi = 10,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
    plot3D:::scatter3D(output.matrix.d.mean_model,output.matrix.obs.diff_model, log10(output.matrix.KDE_model), phi = 90,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
    plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, log10(output.matrix.KDE_test1), phi =10,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
    dev.copy(png,paste(variable.name,"_3D",".png",sep=""),height=1000,width=1000);dev.off()
    dev.copy(postscript,paste(variable.name,"_3D",".eps",sep=""),height=1000,width=1000);dev.off()
    plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, log10(output.matrix.KDE_test1), phi =90,pch=16, bty ="g",type="v",xlab="mdM",ylab="dM",zlab="log10LR", ticktype="detailed",cex.lab=2)
   par(mfrow=c(1,1))
  
    cats_model = unique(population_model$Factor)
    cat.list_model = rep(list(1),length(cats_model))
    for (f in 1:length(cats_model))
    {
      cat.list_model[[f]] = unique(population_model[which(population_model$Factor==cats_model[f]),"Item"])
    }
    
    cats_test1 = unique(population_test1$Factor)
    cat.list_test1 = rep(list(1),length(cats_test1))
    for (f in 1:length(cats_test1))
    {
      cat.list_test1[[f]] = unique(population_test1[which(population_test1$Factor==cats_test1[f]),"Item"])
    }
    
    source("../../../EW_within_functions/logit_maxapproach_function.R")
    logit_res_KDE = logit(LR.matrix_test1=(output.matrix.KDE_model),LR.matrix_test2=(output.matrix.KDE_test1),cat.list_test1=cat.list_model)$p
    dev.copy(png,paste(variable.name,"_logit_curve",".png",sep=""),height=1000,width=1000);dev.off()
    dev.copy(postscript,paste(variable.name,"_logit_curve",".eps",sep=""),height=1000,width=1000);dev.off()
    
    
    true = aggregate(population_test1$Factor,by=list(population_test1$Item),unique)[,-1]
    
    source("../../../EW_within_functions/classification_outcome_withoutWeights_function.r")
    classification.outcomes.KDE = classification.outcomes(LR.matrix = output.matrix.KDE_test1,p.matrix=  logit_res_KDE,cats=cats_test1,cat.list=cat.list_test1,variant="KDE")
    matrix01 = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=length(cats))
    classification.outcomes.KDE$accuracy.fuzzy
    write.table(classification.outcomes.KDE$fuzzy.classification,"detailed_class.txt",sep="\t",quote=F)
    write.table(classification.outcomes.KDE$accuracy.fuzzy,"acc_class.txt",sep="\t",quote=F)
    
    par(mfrow=c(3,1),mar=c(4,5,2,2))
    g=barplot(t(classification.outcomes.KDE$fuzzy.classification[cat.list_test1[[1]],c(4:6)])/100,col=c(7,5,6),ylab="class probability",xlab="class I",cex.lab=2,beside=T,cex.axis=2)
    g=barplot(t(classification.outcomes.KDE$fuzzy.classification[cat.list_test1[[2]],c(5,4,6)])/100,col=c(5,7,6),ylab="class probability",xlab="class II",cex.lab=2,beside=T,cex.axis=2)
    g=barplot(t(classification.outcomes.KDE$fuzzy.classification[cat.list_test1[[3]],c(6,5,4)])/100,col=c(6,5,7),ylab="class probability",xlab="class III",cex.lab=2,beside=T,cex.axis=2)
    dev.copy(png,paste(variable.name,"_LR_classification_barplot2",".png",sep=""));dev.off()
    dev.copy(postscript,paste(variable.name,"_LR_classification_barplot2",".eps",sep=""));dev.off()
    
    
    par(mfrow=c(1,3))
    boxplot(classification.outcomes.KDE$fuzzy.classification[,1]~true,col=c(2,1,1),ylab="membership probabilities");abline(h=0.5,col="red",lwd=2)
    boxplot(classification.outcomes.KDE$fuzzy.classification[,2]~true,col=c(1,2,1),ylab="membership probabilities");abline(h=0.5,col="red",lwd=2)
    boxplot(classification.outcomes.KDE$fuzzy.classification[,3]~true,col=c(1,1,2),ylab="membership probabilities");abline(h=0.5,col="red",lwd=2)
    par(mfrow=c(1,1))
    dev.copy(png,paste(variable.name,"LR_classification_boxplot",".png",sep=""));dev.off()
    dev.copy(postscript,paste(variable.name,"LR_classification_boxplot",".eps",sep=""));dev.off()
    
    plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, (logit_res_KDE), phi = 10, pch=16,bty ="g",type="v",xlab="mean d",ylab="diff d",zlab="probability",ticktype="detailed")
    dev.copy(png,paste(variable.name,"LR_3D_logit",".png",sep=""));dev.off()
    dev.copy(postscript,paste(variable.name,"LR_3D_logit",".eps",sep=""));dev.off()
    
    
    true_model = aggregate(population_model$Factor,by=list(population_model$Item),unique)[,-1]
    true_test1 = aggregate(population_test1$Factor,by=list(population_test1$Item),unique)[,-1]
    
   
    # par(mfrow=c(2,2))
    # dd = output.matrix.KDE_test1
    # q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
    # a =b=d= NULL
    # for (e in 1:nrow(q))
    # {
      # a = c(a,dd[q[e,1]:q[e,2],q[e,1]:q[e,2]])
      # b=c(b,output.matrix.d.mean_test1[q[e,1]:q[e,2],q[e,1]:q[e,2]])
      # d=c(d,output.matrix.obs.diff_test1[q[e,1]:q[e,2],q[e,1]:q[e,2]])
    # }
#
    # tmpa = dd
    # tmpb=output.matrix.d.mean_test1
    # tmpc =output.matrix.obs.diff_test1
    # for (e in 1:nrow(q))
    # {
      # tmpa[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
      # tmpb[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
      # tmpc[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
    # }   
#
    # tmpa = tmpa[which(!is.na(tmpa))]
    # tmpb = tmpb[which(!is.na(tmpb))]
    # tmpc = tmpc[which(!is.na(tmpc))]   
#
    # plot3D:::scatter3D(tmpb,tmpc, log10(tmpa), phi = 0, bty ="g",type="v",xlab="d1",ylab="d2",zlab="different class log10LR", ticktype = "detailed")
    # plot3D:::scatter3D(b,d, log10(a), phi = 0, bty ="g",type="v",xlab="d1",ylab="d2",zlab="same class log10LR", ticktype = "detailed")
    # par(mfrow=c(1,2))
    # plot3D:::scatter3D(tmpb,tmpc, log10(tmpa), phi = 20, bty ="g",type="v",xlab="d1",ylab="d2",zlab="different class log10LR", ticktype = "detailed")
    # plot3D:::scatter3D(b,d, log10(a), phi = 20, bty ="g",type="v",xlab="d1",ylab="d2",zlab="same class log10LR", ticktype = "detailed")
    # dev.copy(png,paste(variable.name,"LR_same_diff_LR",".png",sep=""));dev.off()
    # dev.copy(postscript,paste(variable.name,"LR_same_diff_LR",".eps",sep=""));dev.off()
    # par(mfrow=c(1,2))
    # hist(log10(tmpa))
    # hist(log10(a))
    # dev.copy(png,paste(variable.name,"LR_same_diff_LR_hist",".png",sep=""));dev.off()
    # dev.copy(postscript,paste(variable.name,"LR_same_diff_LR_hist",".eps",sep=""));dev.off()
       
    # dd2 = output.matrix.KDE_test1
    # q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
    # a =NULL
    # for (e in 1:nrow(q))
    # {
      # dd2[q[e,1]:q[e,2],q[e,1]:q[e,2]] = ifelse(output.matrix.KDE_test1[q[e,1]:q[e,2],q[e,1]:q[e,2]]>1,-1,-3)
    # }   
#
    # dd2[dd2>1]= 1 
    # dd2[dd2>0 & dd2<1]= 2  
#
    # min(dd2)
    # max(dd2)   
#
    # col = dd2
    # col[col==-1] = "green";col[col==-3] = "red";col[col==1] = "violet";col[col==2] = "darkgreen"
    # plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, (dd2), phi = 20, bty ="g",type="h",ticktype="detailed",pch = 16,cex=0.5)
    # plot3D:::scatter3D(output.matrix.d.mean_test1,output.matrix.obs.diff_test1, (dd2), phi = 90, bty ="g",type="h",ticktype="detailed",pch = 16,cex=0.5)    
#
    # plot(output.matrix.d.mean_test1,output.matrix.obs.diff_test1,col=col,pch=16,cex=0.5)
    # legend("bottomleft",c("FP","TP","FN","TN"),col=c("violet","green","red","darkgreen"),pch=16)
    # dev.copy(png,paste(variable.name,"LR_FPFNTPTN",".png",sep=""));dev.off()
    # dev.copy(postscript,paste(variable.name,"LR_FPFNTPTN",".eps",sep=""));dev.off()
    
    
    
    
    
    # mask_H1 = matrix(NA,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1))
    # q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
    # for (e in 1:nrow(q))
    # {
      # mask_H1[q[e,1]:q[e,2],q[e,1]:q[e,2]] = 1
    # }
    # mask_H2 = matrix(1,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1))
    # q = matrix(unlist(lapply(cat.list_test1,function(x) range(x))),ncol=2,byrow=T)
    # for (e in 1:nrow(q))
    # {
      # mask_H2[q[e,1]:q[e,2],q[e,1]:q[e,2]] = NA
    # }   
#
#
#
   # which_FP = which(mask_H2==1 & output.matrix.KDE_test1>1)
    # which_TN = which(mask_H2==1 &  output.matrix.KDE_test1<1)
    # which_FN = which(mask_H1== 1 & output.matrix.KDE_test1<1)
    # which_TP = which(mask_H1== 1 & output.matrix.KDE_test1>1)   
#
    # mask_FP = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_FP[which_FP] = 1
    # mask_TN = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_TN[which_TN] = 1
    # mask_FN = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_FN[which_FN] = 1
    # mask_TP = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask_TP[which_TP] = 1    
#
    # mask = matrix(0,nrow=nrow(output.matrix.KDE_test1),ncol=ncol(output.matrix.KDE_test1));mask[which_FP] = 1;mask[which_TN] = 2;mask[which_FN] = 3;mask[which_TP] = 4
    # plot(output.matrix.d.mean_test1,output.matrix.obs.diff_test1,col=mask,cex=0.8,pch=16,,xlab="p1",ylab="p2")
    # legend("topright",c("FP","TN","FN","TP"),col=c(1:4),pch=16,cex=0.7)
    # dev.copy(png,paste(variable.name,"LR_FPFNTPTN",".png",sep=""));dev.off()
    # dev.copy(postscript,paste(variable.name,"LR_FPFNTPTN",".eps",sep=""));dev.off()   
#
#

    par(mfrow=c(1,1),mar=c(5,15,4,2))
    image(1:nrow(output.matrix.KDE_test1),1:ncol(output.matrix.KDE_test1),log10(output.matrix.KDE_test1),xlab="control samples",ylab="recovered samples",cex.lab=2,cex.axis=2)
    dev.copy(postscript, paste(variable.name,"_LR_image",".eps", sep=""));dev.off()
    dev.copy(png,paste(variable.name,"_LR_image",".png",sep=""));dev.off()
    
    image(1:nrow(output.matrix.KDE_model),1:ncol(output.matrix.KDE_model),log10(output.matrix.KDE_model),xlab="control samples",ylab="recovered samples",cex.lab=2,cex.axis=2)
    image(1:nrow(logit_res_KDE),1:ncol(logit_res_KDE),logit_res_KDE,xlab="control samples",ylab="recovered samples",cex.lab=2,cex.axis=2)
    dev.copy(postscript, paste(variable.name,"_p_image",".eps", sep=""));dev.off()
    dev.copy(png,paste(variable.name,"_p_image",".png",sep=""));dev.off()
    
    
    par(mfrow=c(1,2),mar=c(5.1,5.1,4,2))
    plot(density(population_model$V1[which(population_model$Item %in% cat.list_model[[1]])],bw=0.2),main="",xlim=c(-1,16),lwd=2,col=7,xlab="",cex.lab=2,cex.axis=2)
    # points(population_model$Flav[which(sort(MODEL) %in% c(59))],0,cex=1,pch=16,lwd=2,col=7)
    
    lines(density(population_model$V1[which(population_model$Item %in% cat.list_model[[2]])],bw=0.2),main="",lwd=2,col=5)
    # points(population_model$Flav[which(sort(MODEL) %in% c(104:107))],c(0,0,0,0),cex=1,pch=16,lwd=2,col=5)
    
    lines(density(population_model$V1[which(population_model$Item %in% cat.list_model[[3]])],bw=0.2),main="",lwd=2,col=6)
    # points(population_model$Flav[which(sort(MODEL) %in% c(172))],c(0),cex=1,pch=16,lwd=2,col=6)
    
    
    
    plot(density(population_test1$V1[which(population_test1$Item %in% cat.list_test1[[1]])],bw=0.2),main="",xlim=c(-1,16),lwd=2,col=7,xlab="",cex.lab=2,cex.axis=2)
    # points(population_test1$Flav[which(sort(TEST1) %in% c(50:59))],rep(0,10),cex=1,pch=16,lwd=2,col=7)
    
    lines(density(population_test1$V1[which(population_test1$Item %in% cat.list_test1[[2]])],bw=0.2),main="",lwd=2,col=5)
    # points(population_test1$Flav[which(sort(TEST1) %in% c(101:105,107))],rep(0,6),cex=1,pch=16,lwd=2,col=5)
    
    lines(density(population_test1$V1[which(population_test1$Item %in% cat.list_test1[[3]])],bw=0.2),main="",lwd=2,col=6)
    # points(population_test1$Flav[which(sort(TEST1) %in% c(171,173:178))],rep(0,7),cex=1,pch=16,lwd=2,col=6)
    
     
    # par(mfrow=c(1,1))
    # plot(logit_res_KDE[90,],col=c(rep(7,length(cat.list_test1[[1]])),rep(5,length(cat.list_test1[[2]])),rep(6,length(cat.list_test1[[3]]))), pch=16,xlab="samples",ylab="probabilities",cex.lab=2)
    dev.copy(png,paste(variable.name,"_probab",".png",sep=""));dev.off()
    dev.copy(postscript,paste(variable.name,"_probab",".eps",sep=""));dev.off()
    setwd("../")
  }
  
}
par(mfrow=c(1,1),mar=c(5,5,4,2))
catalogues = list.files()[1:25]
RES=array(NA,dim=c(length(cats),length(cats),length(catalogues)))
for (i in 1:length(catalogues))
{
  RES[,,i] = as.matrix(read.table(paste(catalogues[i],"/acc_class.txt",sep=""),header=T))
}
b=barplot((apply(RES,3,diag)),col=c(7,5,6),ylab="class probabilities",xlab="simulated datasets",cex.lab=2,cex.axis=2)
abline(v=b[c(5,10,15,20,25)]+0.6,lwd=2,col="gray",lty=2)
dev.copy(png,paste(variable.name,"_trend",".png",sep=""));dev.off()
dev.copy(postscript,paste(variable.name,"_trend",".eps",sep=""));dev.off()
