source("../../EW_within_functions/duplex.R")

population = read.table("SEMEDX_cw_p_database.txt", header = TRUE)[c(1:(79*4),(317:(316+(79*4)))),]
data.analysed = population
variables.list = list(c("logNaO","logMgO","logAlO","logSiO","logKO","logCaO"))
variables = which(colnames(population) %in% variables.list[[1]])
population.Factor.Item = aggregate(population[,1:2],by=list(population$Item),FUN=unique)[,-1]
population.means = aggregate(population[,variables],by=list(population$Item),FUN=mean)[,-1]
population.means = cbind(population.Factor.Item,Piece=rep(1,times=nrow(population.means)),population.means)

cats = unique(population.means$Factor)
cat.list = rep(list(1),length(cats))
for (f in 1:length(cats))
{
  cat.list[[f]] = unique(population.means[which(population.means$Factor==cats[f]),"Item"])
}

Sets=2
MODEL=TEST1=TEST2=NULL
for (s in 1:length(cats))
{
  duplex_res = duplex(as.matrix(population.means[cat.list[[s]],-c(1:3)]),Sets=Sets) #KS(population.means[cat.list[[s]],-c(1:3)],k=0.6*nrow(population.means[cat.list[[s]],-c(1:3)])) #
  MODEL = c(MODEL,duplex_res$model+cat.list[[s]][1]-1)
  TEST1 = c(TEST1,duplex_res$test1+cat.list[[s]][1]-1)
}

population_model = population.means[which(population.means$Item %in% MODEL),]
population_model$Item = rep(1:length(unique(population_model$Item)),each=length(unique(population_model$Piece)))
population_test1 = population.means[which(population.means$Item %in% TEST1),]
population_test1$Item = rep(1:length(unique(population_test1$Item)),each=length(unique(population_test1$Piece)))

cats_model = unique(population_model$Factor)
cat.list_model = rep(list(1),length(cats_model))
for (f in 1:length(cats_model))
{
  cat.list_model[[f]] = unique(population_model[which(population_model$Factor==cats_model[f]),"Item"])
}

cats_test1 = unique(population_test1$Factor)
cat.list_test1 = rep(list(1),length(cats_test1))
for (f in 1:length(cats_test1))
{
  cat.list_test1[[f]] = unique(population_test1[which(population_test1$Factor==cats_test1[f]),"Item"])
}

pca1 = prcomp(population_model[which(population_model$Item %in% cat.list_model[[1]]),variables],center=T,scale=F)
plot(pca1$sdev^2)
##3 PCs for class p

pca2 = prcomp(population_model[which(population_model$Item %in% cat.list_model[[2]]),variables],center=T,scale=F)
plot(pca2$sdev^2)
##3 PCs for class cw


n1=3
n2=3

library(rrcovHD)
library(prospectr)
caldata = population_test1
m  = length(unique(caldata$Item))
SD = OD = SD_mdatools = OD_mdatools = probab=matrix(NA,nrow=nrow(population_test1),ncol=length(unique(population_test1$Factor)))
for (i in 1:m)
{
  train = caldata[-which(caldata$Item == i),]
  test = caldata[which(caldata$Item == i),]

  rows.1 = which(train$Factor==unique(train$Factor)[1])
  rows.2 = which(train$Factor==unique(train$Factor)[2])
  
  pca1 = prcomp(train[rows.1,variables],scale=F,center=T)$rotation[,1:n1]
  pca2 = prcomp(train[rows.2,variables],scale=F,center=T)$rotation[,1:n2]
  
  sd1=prcomp(train[rows.1,variables],scale=F,center=T)$sdev[1:n1]
  sd2=prcomp(train[rows.2,variables],scale=F,center=T)$sdev[1:n2]
  
  test_on1 = ((as.matrix(test[,variables] - matrix(apply(train[rows.1,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T))))%*%pca1
  test_on2 = ((as.matrix(test[,variables] - matrix(apply(train[rows.2,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T))))%*%pca2
  
  SD_on1 = sqrt(apply(test_on1^2/matrix(sd1^2,nrow=nrow(test[,variables]),ncol=ncol(test_on1),byrow=T),1,sum))
  SD_on2 = sqrt(apply(test_on2^2/matrix(sd2^2,nrow=nrow(test[,variables]),ncol=ncol(test_on2),byrow=T),1,sum))
  SD[i,] = c(as.matrix(SD_on1),as.matrix(SD_on2))
  
  xhat_on1 = (test_on1)%*%t(pca1)+matrix(apply(train[rows.1,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  xhat_on2 = (test_on2)%*%t(pca2)+matrix(apply(train[rows.2,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
 
  
  OD_on1 = sqrt(apply((test[,variables]-xhat_on1)^2,1,sum))
  OD_on2 = sqrt(apply((test[,variables]-xhat_on2)^2,1,sum))
  OD[i,] = c(as.matrix(OD_on1),as.matrix(OD_on2))

    
  sd_cutoff1 = sqrt(qchisq(p=0.975,df=n1))
  sd_cutoff2 = sqrt(qchisq(p=0.975,df=n2))
  od_cutoff1 = (median(OD_on1^(2/3))+mad(OD_on1^(2/3))/1.4826*qnorm(p=0.975))^(3/2)
  od_cutoff2 = (median(OD_on2^(2/3))+mad(OD_on2^(2/3))/1.4826*qnorm(p=0.975))^(3/2)
   
  
  
  
  
  
  
  
  ############
  ##################
  ##################
  ################
  ##############
  library(mdatools)
  
  # split data
  x.1 = train[which(train$Factor==cats[1]), ]
  x.2 = train[which(train$Factor==cats[2]), ]
  
  # create individual models
  m.1 = simca(x.1[,variables], classname = cats[1],scale=F)
  m.1 = selectCompNum(m.1, n1)
  print(m.1$loadings);print(pca1)
  
  m.2 = simca(x.2[,variables], classname = cats[2],scale=F)
  m.2 = selectCompNum(m.2, n2)
  print(m.2$loadings);print(pca2)
  
  
  # combine models into SIMCAM objects, show statistics and plots
  m = simcam(list(m.1, m.2), info = "")
  summary(m)
  
  # apply the SIMCAM model to test set and show statistics and plots
  res = predict(m, test[,variables], test$Factor)
  summary(res)
  # plotPredictions(res)
  SD_mdatools[i,] =  c(sqrt(res$pred.res$p$T2[,n1]),sqrt(res$pred.res$cw$T2[,n2]))

  OD_mdatools[i,] =   c(sqrt(res$pred.res$p$Q[,n1]),sqrt(res$pred.res$cw$Q[,n2]))

  
  probab[i,1] = getProbabilities(m.1, ncomp=n1, OD[i,1]^2, h=SD[i,1]^2)
  probab[i,2] = getProbabilities(m.2, ncomp=n2, OD[i,2]^2, h=SD[i,2]^2)
  
  
  
  
  
  
  
  
}


SD_mdatools-SD
OD_mdatools-OD

par(mfrow=c(2,1),mar=c(4,5,2,2))
g=barplot(t(probab[cat.list_test1[[1]],]),col=c(3,4),ylab="class probability",xlab="class p",cex.lab=2,beside=T,cex.axis=2,names=cat.list_test1[[1]])
g=barplot(t(probab[cat.list_test1[[2]],]),col=c(3,4),ylab="class probability",xlab="class cw",cex.lab=2,beside=T,cex.axis=2,names=cat.list_test1[[2]])
dev.copy(png,paste("barplot2",".png",sep=""));dev.off()
dev.copy(postscript,paste("barplot2",".eps",sep=""));dev.off()

true = aggregate(population_test1$Factor,by=list(population_test1$Item),unique)[,-1]
predicted = ifelse(apply(probab,1,which.max)==1,"p","cw")
table(true,predicted)
# data.frame(probab_on1,probab_on2)
# 
# SIMCA_results = CSimca(Species~., data=caldata, k=c(3,3,3))
# SIMCA_predict = predict(SIMCA_results, newdata=x.test[,1:4])
# SIMCA_predict@odsc/cbind(OD_on1/od_cutoff1,OD_on2/od_cutoff2,OD_on3/od_cutoff3)
# SIMCA_predict@sdsc/cbind(SD_on1/sd_cutoff,SD_on2/sd_cutoff,SD_on3/sd_cutoff)
# 
# # cbind(SD_on1/sd_cutoff,SD_on2/sd_cutoff,SD_on3/sd_cutoff)[1:10,]
# # cbind(OD_on1/od_cutoff1,OD_on2/od_cutoff2,OD_on3/od_cutoff3)[1:10,]
# 
# 
# plot(SIMCA_predict@sdsc[,1], SIMCA_predict@odsc[,1], col=test$CLAS, ylab="orthogonal distance", xlab="score distance",pch=16)
# abline(v=1, h=1, col="red")
# dev.copy(postscript,"SIMCA1.eps");dev.off()
# plot(SIMCA_predict@sdsc[,2], SIMCA_predict@odsc[,2], col=test$CLAS,
#      ylab="orthogonal distance", xlab="score distance",pch=16)
# abline(v=1, h=1, col="red")
# dev.copy(postscript,"SIMCA2.eps");dev.off()
# plot(SIMCA_predict@sdsc[,3], SIMCA_predict@odsc[,3], col=test$CLAS,
#      ylab="orthogonal distance", xlab="score distance",pch=16)
# abline(v=1, h=1, col="red")
# dev.copy(postscript,"SIMCA3.eps");dev.off()
# 
# 
