source("../../EW_within_functions/duplex.R")

population = read.table("wines_data13.txt", header = TRUE)
data.analysed = population
variables.list = list(colnames(population[,-c(1:3)]))
variables = which(colnames(population) %in% variables.list[[1]])
population.Factor.Item = aggregate(population[,1:2],by=list(population$Item),FUN=unique)[,-1]
population.means = aggregate(population[,variables],by=list(population$Item),FUN=mean)[,-1]
population.means = cbind(population.Factor.Item,Piece=rep(1,times=nrow(population.means)),population.means)

cats = unique(population.means$Factor)
cat.list = rep(list(1),length(cats))
for (f in 1:length(cats))
{
  cat.list[[f]] = unique(population.means[which(population.means$Factor==cats[f]),"Item"])
}

Sets=2
MODEL=TEST1=TEST2=NULL
for (s in 1:length(cats))
{
  duplex_res = duplex(as.matrix(population.means[cat.list[[s]],-c(1:3)]),Sets=Sets) #KS(population.means[cat.list[[s]],-c(1:3)],k=0.6*nrow(population.means[cat.list[[s]],-c(1:3)])) #
  MODEL = c(MODEL,duplex_res$model+cat.list[[s]][1]-1)
  TEST1 = c(TEST1,duplex_res$test1+cat.list[[s]][1]-1)
}

population_model = population.means[which(population.means$Item %in% MODEL),]
population_model$Item = rep(1:length(unique(population_model$Item)),each=length(unique(population_model$Piece)))
population_test1 = population.means[which(population.means$Item %in% TEST1),]
population_test1$Item = rep(1:length(unique(population_test1$Item)),each=length(unique(population_test1$Piece)))

cats_model = unique(population_model$Factor)
cat.list_model = rep(list(1),length(cats_model))
for (f in 1:length(cats_model))
{
  cat.list_model[[f]] = unique(population_model[which(population_model$Factor==cats_model[f]),"Item"])
}

cats_test1 = unique(population_test1$Factor)
cat.list_test1 = rep(list(1),length(cats_test1))
for (f in 1:length(cats_test1))
{
  cat.list_test1[[f]] = unique(population_test1[which(population_test1$Factor==cats_test1[f]),"Item"])
}

pca1 = prcomp(population_model[which(population_model$Item %in% cat.list_model[[1]]),variables],center=T,scale=T)
plot(pca1$sdev^2)
barplot(cumsum((pca1$sdev^2))/sum((pca1$sdev^2)))
abline(h=0.9)
##7 PCs for class 1

pca2 = prcomp(population_model[which(population_model$Item %in% cat.list_model[[2]]),variables],center=T,scale=T)
plot(pca2$sdev^2)
barplot(cumsum((pca2$sdev^2))/sum((pca2$sdev^2)))
abline(h=0.9)
##8 PCs for class 2

pca3 = prcomp(population_model[which(population_model$Item %in% cat.list_model[[3]]),variables],center=T,scale=T)
plot(pca3$sdev^2)
barplot(cumsum((pca3$sdev^2))/sum((pca3$sdev^2)))
abline(h=0.9)
##7 PCs for class 3

n1 = 7
n2 = 8
n3 = 7

library(rrcovHD)
library(prospectr)
caldata = population_test1
m  = length(unique(caldata$Item))
SD = OD = SD_mdatools = OD_mdatools = probab=matrix(NA,nrow=nrow(population_test1),ncol=length(unique(population_test1$Factor)))
for (i in 1:m)
{
  train = caldata[-which(caldata$Item == i),]
  test = caldata[which(caldata$Item == i),]

  rows.1 = which(train$Factor==unique(train$Factor)[1])
  rows.2 = which(train$Factor==unique(train$Factor)[2])
  rows.3 = which(train$Factor==unique(train$Factor)[3])
  
  pca1 = prcomp(train[rows.1,variables],scale=T,center=T)$rotation[,1:n1]
  pca2 = prcomp(train[rows.2,variables],scale=T,center=T)$rotation[,1:n2]
  pca3 = prcomp(train[rows.3,variables],scale=T,center=T)$rotation[,1:n3]
  
  sd1=prcomp(train[rows.1,variables],scale=T,center=T)$sdev[1:n1]
  sd2=prcomp(train[rows.2,variables],scale=T,center=T)$sdev[1:n2]
  sd3=prcomp(train[rows.3,variables],scale=T,center=T)$sdev[1:n3]
  
  mean1 =  matrix(apply(train[rows.1,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  mean2 = matrix(apply(train[rows.2,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  mean3 = matrix(apply(train[rows.3,variables],2,mean),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  stdev1 = matrix(apply(train[rows.1,variables],2,sd),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  stdev2 = matrix(apply(train[rows.2,variables],2,sd),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  stdev3 = matrix(apply(train[rows.3,variables],2,sd),nrow=nrow(test[,variables]),ncol=ncol(test[,variables]),byrow=T)
  
  test_on1 = ((as.matrix(test[,variables] - mean1)/stdev1))%*%pca1
  test_on2 = ((as.matrix(test[,variables] - mean2)/stdev2))%*%pca2
  test_on3 = ((as.matrix(test[,variables] - mean3)/stdev3))%*%pca3
  
  SD_on1 = sqrt(apply(test_on1^2/matrix(sd1^2,nrow=nrow(test[,variables]),ncol=ncol(test_on1),byrow=T),1,sum))
  SD_on2 = sqrt(apply(test_on2^2/matrix(sd2^2,nrow=nrow(test[,variables]),ncol=ncol(test_on2),byrow=T),1,sum))
  SD_on3 = sqrt(apply(test_on3^2/matrix(sd3^2,nrow=nrow(test[,variables]),ncol=ncol(test_on3),byrow=T),1,sum))
  SD[i,] = c(as.matrix(SD_on1),as.matrix(SD_on2),as.matrix(SD_on3))
  
  xhat_on1 = ((test_on1)%*%t(pca1))
  xhat_on2 = ((test_on2)%*%t(pca2))
  xhat_on3 = ((test_on3)%*%t(pca3))
  
  OD_on1 = sqrt(apply((((as.matrix(test[,variables] - mean1)/stdev1))-xhat_on1)^2,1,sum))
  OD_on2 = sqrt(apply((((as.matrix(test[,variables] - mean2)/stdev2))-xhat_on2)^2,1,sum))
  OD_on3 = sqrt(apply((((as.matrix(test[,variables] - mean3)/stdev3))-xhat_on3)^2,1,sum))
  OD[i,] = c(as.matrix(OD_on1),as.matrix(OD_on2),as.matrix(OD_on3))

    
  sd_cutoff1 = sqrt(qchisq(p=0.975,df=n1))
  sd_cutoff2 = sqrt(qchisq(p=0.975,df=n2))
  sd_cutoff3 = sqrt(qchisq(p=0.975,df=n3))
  
  od_cutoff1 = (median(OD_on1^(2/3))+mad(OD_on1^(2/3))/1.4826*qnorm(p=0.975))^(3/2)
  od_cutoff2 = (median(OD_on2^(2/3))+mad(OD_on2^(2/3))/1.4826*qnorm(p=0.975))^(3/2)
  od_cutoff3 = (median(OD_on3^(2/3))+mad(OD_on3^(2/3))/1.4826*qnorm(p=0.975))^(3/2)
  
  
  
  
  
  
  
  
  ############
  ##################
  ##################
  ################
  ##############
  library(mdatools)

  # split data
  x.1 = train[which(train$Factor==cats[1]), ]
  x.2 = train[which(train$Factor==cats[2]), ]
  x.3 = train[which(train$Factor==cats[3]), ]

  # create individual models
  m.1 = simca(x.1[,variables], classname = cats[1],scale=T)
  m.1 = selectCompNum(m.1, n1)
  print(m.1$loadings);print(pca1)
  
  m.2 = simca(x.2[,variables], classname = cats[2],scale=T)
  m.2 = selectCompNum(m.2, n2)
  print(m.2$loadings);print(pca2)
  
  m.3 = simca(x.3[,variables], classname = cats[3],scale=T)
  m.3 = selectCompNum(m.3, n3)
  print(m.3$loadings);print(pca3)
  
  # combine models into SIMCAM objects, show statistics and plots
  # m = simcam(list(m.1, m.2), info = "")
  m = simcam(list(m.1, m.2, m.3), info = "")
  summary(m)
  
  # apply the SIMCAM model to test set and show statistics and plots
  res = predict(m, test[,variables], test$Factor)
  summary(res)
  # plotPredictions(res)
  SD_mdatools[i,] =  c(sqrt(res$pred.res$c1$T2[,n1]),sqrt(res$pred.res$c2$T2[,n2]),sqrt(res$pred.res$c3$T2[,n3]))

  OD_mdatools[i,] =   c(sqrt(res$pred.res$c1$Q[,n1]),sqrt(res$pred.res$c2$Q[,n2]),sqrt(res$pred.res$c3$Q[,n3]))

  
  probab[i,1] = getProbabilities(m.1, ncomp=n1, OD[i,1]^2, h=SD[i,1]^2)
  probab[i,2] = getProbabilities(m.2, ncomp=n2, OD[i,2]^2, h=SD[i,2]^2)
  probab[i,3] = getProbabilities(m.3, ncomp=n3, OD[i,3]^2, h=SD[i,3]^2)
  
  
  
  
  
  
  
  
}


SD_mdatools-SD
OD_mdatools-OD


par(mfrow=c(3,1),mar=c(4,5,2,2))
g=barplot(t(probab[cat.list_test1[[1]],c(1:3)]),col=c(7,5,6),ylab="class probability",xlab="class 1",cex.lab=2,beside=T,cex.axis=2,names=cat.list_test1[[1]],cex.names=1.5)
g=barplot(t(probab[cat.list_test1[[2]],c(2,1,3)]),col=c(5,7,6),ylab="class probability",xlab="class 2",cex.lab=2,beside=T,cex.axis=2,names=cat.list_test1[[2]],cex.names=1.5)
g=barplot(t(probab[cat.list_test1[[3]],c(3,2,1)]),col=c(6,5,7),ylab="class probability",xlab="class 3",cex.lab=2,beside=T,cex.axis=2,names=cat.list_test1[[3]],cex.names=1.5)

dev.copy(png,paste("barplot2",".png",sep=""));dev.off()
dev.copy(postscript,paste("barplot2",".eps",sep=""));dev.off()

true = aggregate(population_test1$Factor,by=list(population_test1$Item),unique)[,-1]
predicted = ifelse(apply(probab,1,which.max)==1,"p","cw")
table(true,predicted)
# data.frame(probab_on1,probab_on2)
# 
# SIMCA_results = CSimca(Species~., data=caldata, k=c(3,3,3))
# SIMCA_predict = predict(SIMCA_results, newdata=x.test[,1:4])
# SIMCA_predict@odsc/cbind(OD_on1/od_cutoff1,OD_on2/od_cutoff2,OD_on3/od_cutoff3)
# SIMCA_predict@sdsc/cbind(SD_on1/sd_cutoff,SD_on2/sd_cutoff,SD_on3/sd_cutoff)
# 
# # cbind(SD_on1/sd_cutoff,SD_on2/sd_cutoff,SD_on3/sd_cutoff)[1:10,]
# # cbind(OD_on1/od_cutoff1,OD_on2/od_cutoff2,OD_on3/od_cutoff3)[1:10,]
# 
# 
# plot(SIMCA_predict@sdsc[,1], SIMCA_predict@odsc[,1], col=test$CLAS, ylab="orthogonal distance", xlab="score distance",pch=16)
# abline(v=1, h=1, col="red")
# dev.copy(postscript,"SIMCA1.eps");dev.off()
# plot(SIMCA_predict@sdsc[,2], SIMCA_predict@odsc[,2], col=test$CLAS,
#      ylab="orthogonal distance", xlab="score distance",pch=16)
# abline(v=1, h=1, col="red")
# dev.copy(postscript,"SIMCA2.eps");dev.off()
# plot(SIMCA_predict@sdsc[,3], SIMCA_predict@odsc[,3], col=test$CLAS,
#      ylab="orthogonal distance", xlab="score distance",pch=16)
# abline(v=1, h=1, col="red")
# dev.copy(postscript,"SIMCA3.eps");dev.off()
# 
# 
